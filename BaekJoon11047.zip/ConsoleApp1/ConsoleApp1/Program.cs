﻿using System.Collections;
string[]input = Console.ReadLine().Split(' ');
int i_Coin_count = Int32.Parse(input[0]);// 코인 입력개수 
int i_Price = Int32.Parse(input[1]);// 코인 금액 

int i_Check = 0;
int i_col = 0;

List<int> numbers = new List <int> ();

for(int i= 0;i< i_Coin_count;i++)
{

    numbers.Add(Int32.Parse(Console.ReadLine()));

}

numbers.Sort();

i_Check = i_Coin_count;
while (i_Price > 0)
{
    if (i_Check - 1 < 0)
        break;
    if (i_Price - (numbers[i_Check - 1])>= 0)
    {
        i_Price = i_Price - (int)numbers[i_Check-1];
        i_col++;
    }

    else
        i_Check = i_Check - 1;


}

Console.WriteLine(i_col);
